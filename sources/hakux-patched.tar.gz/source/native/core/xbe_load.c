/*
 * hakuX native core — XBE loader.
 *
 * Header fields beyond hle_xbe_parse (offsets from the base address):
 *   0x12C TLS directory VA, 0x130 PE stack commit size.
 *
 * As the Xbox kernel loads an XBE, the headers and the preloaded sections
 * get memory and the rest of the image is address space only, until
 * XeLoadSection (ex.c) brings a section in; XeUnloadSection gives its pages
 * back. Titles with many sections count on that memory (Fable preloads 15
 * of 107: backing the whole image left it 4 MiB short in gameplay).
 */
#include "native/core/xbe_load.h"

#include <stdlib.h>
#include <string.h>

#define XBE_SECTIONS     0x120
#define XBE_TLS_DIR      0x12C
#define XBE_STACK_COMMIT 0x130
#define SEC_HDR_SIZE     0x38
#define SEC_REFS         0x18

bool nc_xbe_back(NcVm *vm, uint32_t va, uint32_t len)
{
    const uint64_t end = nc_align_up((uint64_t)va + len, NC_PAGE);
    for (uint64_t p = va & ~(NC_PAGE - 1); p < end;) {
        if (nc_vm_phys(vm, (uint32_t)p) != UINT32_MAX) {
            p += NC_PAGE;
            continue;
        }
        uint64_t q = p;
        while (q < end && nc_vm_phys(vm, (uint32_t)q) == UINT32_MAX) {
            q += NC_PAGE;
        }
        if (!nc_vm_alloc_at(vm, (uint32_t)p, (uint32_t)(q - p), NULL)) {
            return false;
        }
        p = q;
    }
    return true;
}

bool nc_xbe_load(NcVm *vm, const NcDisc *disc, const char *path, const NcKernel *k, NcXbe *out)
{
    memset(out, 0, sizeof(*out));
    if (!nc_disc_find(disc, path, &out->file)) {
        nc_log("hakuX-native", "xbe: %s not on the disc", path);
        return false;
    }

    uint8_t probe[0x180];
    if (out->file.size < sizeof(probe) || !nc_disc_read(disc, &out->file, 0, probe, sizeof(probe))) {
        return false;
    }
    const uint32_t base = nc_rd32(probe + 0x104);
    const uint32_t hdr_size = nc_rd32(probe + 0x108);
    const uint32_t image_size = nc_rd32(probe + 0x10C);
    if (hdr_size < sizeof(probe) || hdr_size > out->file.size || base & (NC_PAGE - 1)) {
        nc_log("hakuX-native", "xbe: bad header (base %08x, headers %u)", base, hdr_size);
        return false;
    }

    const uint32_t span = nc_align_up(image_size > hdr_size ? image_size : hdr_size, NC_PAGE);
    if (!nc_xbe_back(vm, base, hdr_size)) {
        return false;
    }
    uint8_t *hdr = nc_vm_host(vm, base);
    if (!nc_disc_read(disc, &out->file, 0, hdr, hdr_size)) {
        return false;
    }
    int rc = hle_xbe_parse(hdr, hdr_size, &out->info);
    if (rc != HLE_XBE_OK) {
        nc_log("hakuX-native", "xbe: parse failed (%d)", rc);
        return false;
    }
    const HleXbeInfo *x = &out->info;
    out->tls_dir = nc_rd32(hdr + XBE_TLS_DIR);
    out->stack_commit = nc_rd32(hdr + XBE_STACK_COMMIT);

    unsigned loaded = 0;
    for (unsigned i = 0; i < x->nsections; i++) {
        const HleXbeSection *s = &x->sections[i];
        if (!(s->flags & HLE_XBE_SEC_PRELOAD)) {
            continue; /* XeLoadSection brings it in */
        }
        if ((uint64_t)s->va + s->vsize > (uint64_t)base + span || s->va < base) {
            nc_log("hakuX-native", "xbe: section %s outside the image", s->name);
            return false;
        }
        if (!nc_xbe_back(vm, s->va, s->vsize)) {
            nc_log("hakuX-native", "xbe: no memory for section %s", s->name);
            return false;
        }
        uint32_t n = s->raw_size < s->vsize ? s->raw_size : s->vsize;
        if (n && !nc_disc_read(disc, &out->file, s->raw_off, nc_vm_host(vm, s->va), n)) {
            nc_log("hakuX-native", "xbe: read of section %s failed", s->name);
            return false;
        }
        /* Loaded once, as XeLoadSection counts: an XeUnloadSection frees it. */
        nc_vm_wr32(vm, nc_rd32(hdr + XBE_SECTIONS) + i * SEC_HDR_SIZE + SEC_REFS, 1);
        loaded++;
    }
    uint32_t backed = 0;
    for (uint32_t p = base; p < base + span; p += NC_PAGE) {
        backed += nc_vm_phys(vm, p) != UINT32_MAX ? NC_PAGE : 0;
    }

    /* Kernel thunk table: 0x80000000 | ordinal entries, zero-terminated. */
    for (uint32_t t = x->kernel_thunk;; t += 4) {
        uint32_t v = nc_vm_rd32(vm, t);
        if (!v) {
            break;
        }
        if (!(v & 0x80000000u)) {
            nc_log("hakuX-native", "xbe: thunk %08x is not an ordinal import (%08x)", t, v);
            return false;
        }
        unsigned ordinal = v & 0x7FFFFFFFu;
        uint32_t target = nc_kernel_resolve(k, ordinal);
        if (!target) {
            nc_log("hakuX-native", "xbe: import of unknown kernel ordinal %u", ordinal);
            return false;
        }
        nc_vm_wr32(vm, t, target);
        out->thunks++;
    }

    char imports[1024] = "", missing[1024] = "";
    size_t n = 0, nm = 0;
    unsigned nmissing = 0;
    for (uint32_t t = x->kernel_thunk; nc_vm_rd32(vm, t) && n < sizeof(imports) - 8; t += 4) {
        uint32_t target = nc_vm_rd32(vm, t);
        for (unsigned o = 1; o < NC_KORDINAL_MAX; o++) {
            if (nc_kernel_resolve(k, o) == target) {
                n += (size_t)snprintf(imports + n, sizeof(imports) - n, "%s%u", n ? "," : "", o);
                const NcKExport *e = nc_kernel_export(o);
                if (e->abi != NC_KABI_DATA && !nc_kernel_implemented(k, o)) {
                    nmissing++;
                    if (nm < sizeof(missing) - 40) {
                        nm += (size_t)snprintf(missing + nm, sizeof(missing) - nm, "%s%s", nm ? ", " : "", e->name);
                    }
                }
                break;
            }
        }
    }

    {
        static const struct { uint32_t title, va; unsigned n; uint8_t from[16], to[16]; const char *what; } k_patches[] = {
            { 0x4d530064u, 0x190565u, 6,
              { 0x55, 0x8b, 0xec, 0x83, 0xec, 0x0c }, { 0xb8, 0x68, 0x00, 0x00, 0x00, 0xc3 },
              "Halo 2: all campaign levels unlocked" },
            { 0x4d530064u, 0x19052cu, 13,
              { 0x55, 0x8b, 0xec, 0x81, 0xec, 0xe4, 0x01, 0x00, 0x00, 0x53, 0x8d, 0x5d, 0xfc },
              { 0xc7, 0x07, 0x68, 0x00, 0x00, 0x00, 0xc7, 0x06, 0x01, 0x00, 0x00, 0x00, 0xc3 },
              "Halo 2: every profile has campaign progress" },
        };
        const char *off = getenv("HAKUX_NO_TITLE_PATCHES");
        for (unsigned i = 0; i < sizeof(k_patches) / sizeof(k_patches[0]) && !(off && off[0] == '1'); i++) {
#ifdef HAKUX_XBOX2
            /* The old 0x68 override capped campaign selection at Cairo Station
             * and interfered with imported completed profiles. Native signed
             * saves contain the correct campaign progress. */
            if (k_patches[i].title == 0x4d530064u) {
                continue;
            }
#endif
            if (k_patches[i].title != x->title_id) {
                continue;
            }
            uint8_t *p = nc_vm_host(vm, k_patches[i].va);
            if (p && !memcmp(p, k_patches[i].from, k_patches[i].n)) {
                memcpy(p, k_patches[i].to, k_patches[i].n);
                nc_log("hakuX-native-frontier", "title patch: %s (%08x)", k_patches[i].what, k_patches[i].va);
            } else {
                nc_log("hakuX-native-frontier", "title patch: %s: the bytes at %08x differ, not applied",
                       k_patches[i].what, k_patches[i].va);
            }
        }
    }
    nc_log("hakuX-native-frontier",
           "stage S0 xbe loaded: title %08x base %08x image %u KiB (%u KiB in memory), %u/%u sections, "
           "entry %08x, %u kernel imports, tls %08x",
           x->title_id, base, span >> 10, backed >> 10, loaded, x->nsections, x->entry, out->thunks,
           out->tls_dir);
    nc_log("hakuX-native-imports", "title %08x %s", x->title_id, imports);
    if (nmissing) {
        /* told now, not at the call (that stops the game) */
        nc_log("hakuX-native-imports", "title %08x imports %u kernel functions not implemented here: %s",
               x->title_id, nmissing, missing);
    }
    return true;
}
