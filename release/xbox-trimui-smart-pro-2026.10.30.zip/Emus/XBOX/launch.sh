#!/bin/sh
exec /bin/sh /mnt/SDCARD/Data/ports/hakux-disc.sh /mnt/SDCARD/Data/ports/hakux/run.sh "$@"
