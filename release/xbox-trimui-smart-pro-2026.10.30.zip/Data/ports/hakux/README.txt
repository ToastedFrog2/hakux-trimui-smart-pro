AUTOMATIC MAINUI + OSD MEMORY RELEASE — see repository for limited device test results.

Xbox for the original TrimUI Smart Pro TG5040

Install Data/ and Emus/ into the SD card root, merging folders. Games go in
Roms/XBOX. PortMaster is not required. Default scale on a fresh install is 0.5x.
Existing saves, caches, scale, picture and swap settings are not in this payload.
Menu opens settings; hold Start+Select about 1.2 seconds to exit.
Scale changes require Apply scale and restart; save in-game first.

Experimental: missing/black textures, slowdowns, crashes and driver stalls
remain possible. First-run shaders can stutter; persistent black textures
are not fixed by this release. No guaranteed 30 FPS or all-game compatibility.
Swap is automatic for all games: existing configured/system swap is reused;
otherwise 512 MiB is created on writable internal ext4 with at least 1 GiB
free before allocation. First launch may take longer. Existing files/settings
are preserved; setup failures are logged and do not stop the game. Create
disable-swap in the app folder to opt out. Details: docs/INSTALL.md in the
repository. No games, BIOS, saves, swap file or shader cache are bundled.

Based on rfandango/hakuX; matching modified source is in sources/ in the
accompanying repository. License texts are in licenses/. Preserve attribution.

Menu render scales: 0.35x / 0.5x / 0.75x / 1x. Apply scale and restart
to change resolution. 0.75x is sharper than 0.5x and can be slower.

Menu → Frame skip: Off / Skip 1 (Display). Changes apply live and persist.
This skips alternate display updates, preserving all guest drawing/timing.
Menus always update normally. This is not a texture fix or FPS guarantee.

MainUI and the TrimUI OSD close automatically for Xbox games and return on
exit. No menu toggle or setup is required. An independent guard restores
them if the launcher dies. Linux, networking and input remain running.

Menu > Controller Mapping: Up/Down selects an Xbox action; Left/Right or A
changes its physical input. B returns, Menu resumes. Changes persist for all
games in controller-map. Reset to defaults restores the original layout.
Physical Menu, menu navigation and Start + Select to exit remain fixed.

Fresh installs use default controls: L3/R3 are Xbox stick clicks. No saved
controller-map, menu-settings or render-scale file is bundled. Existing
settings on an updated card are preserved; use Controller Mapping > Reset
to defaults to clear a previous layout. The FPS overlay has been removed.
