#include "../platform/menu.c"
#include <assert.h>
#include <sys/wait.h>
static Uint32 ticks;
static Uint8 buttons[SDL_CONTROLLER_BUTTON_MAX];
static Sint16 axes[SDL_CONTROLLER_AXIS_MAX];
static bool paused;
static void teardown_marker(void) {FILE *f=fopen("UNSAFE-TEARDOWN","w");if(f){fputs("ran",f);fclose(f);}}
static int aspect,filter,fxaa;
Uint32 SDL_GetTicks(void) { return ticks; }
Uint8 SDL_GameControllerGetButton(SDL_GameController *p,SDL_GameControllerButton b) { return buttons[b]; }
Sint16 SDL_GameControllerGetAxis(SDL_GameController *p,SDL_GameControllerAxis a) { return axes[a]; }
float hle_host_render_scale(void) {return .5f;}
void nc_pause_set(bool b) {paused=b;}
bool nc_paused(void) {return paused;}
void nc_present_set_aspect(int n) {aspect=n;}
void nc_present_set_upscale(int n) {filter=n;}
void nc_present_set_fxaa(bool n) {fxaa=n;}
static unsigned draws,rect_count;
static unsigned bound_w,bound_h;
static void VKAPI_CALL record(VkCommandBuffer cb,uint32_t n,const VkClearAttachment *a,uint32_t m,const VkClearRect *r)
{
    assert(n==1&&a->aspectMask==VK_IMAGE_ASPECT_COLOR_BIT&&m>0&&m<=8192);
    for(unsigned i=0;i<m;i++) {
        assert(r[i].rect.offset.x>=0&&r[i].rect.offset.y>=0&&r[i].layerCount==1);
        assert((unsigned)r[i].rect.offset.x+r[i].rect.extent.width<=bound_w);
        assert((unsigned)r[i].rect.offset.y+r[i].rect.extent.height<=bound_h);
    }
    draws++;rect_count+=m;
}
static SDL_GameController *pad=(SDL_GameController*)(uintptr_t)1;
static void press(SDL_GameControllerButton b) {
    buttons[b]=1;hakux_menu_input(pad);buttons[b]=0;hakux_menu_input(pad);
}
static void menu(void) {hakux_menu_key(true);hakux_menu_input(pad);hakux_menu_key(false);hakux_menu_input(pad);}
int main(void)
{
    char *argv[]={"hakux.aarch64","/tmp/hakux-disc.RANDOM/Halo 2.iso","hdd=hdd",NULL};
    hakux_menu_init(3,argv);hakux_menu_ready();
    assert(ui.scale==1&&!ui.open);
    assert(write_setting("render-scale","0.5"));
    menu();assert(ui.open&&paused);
    press(SDL_CONTROLLER_BUTTON_DPAD_DOWN);assert(ui.row==SCALE);
    press(SDL_CONTROLLER_BUTTON_DPAD_LEFT);assert(ui.scale==0);
    FILE *f=fopen("render-scale","r");float value;assert(fscanf(f,"%f",&value)==1&&value==.5f);fclose(f);
    assert(hle_host_render_scale()==.5f); /* The running surface scale was untouched. */
    press(SDL_CONTROLLER_BUTTON_B);assert(!ui.open&&!paused);
    buttons[SDL_CONTROLLER_BUTTON_A]=1;menu();assert(ui.open&&ui.scale==0);
    buttons[SDL_CONTROLLER_BUTTON_A]=0;hakux_menu_input(pad);
    ui.row=ASPECT;press(SDL_CONTROLLER_BUTTON_DPAD_RIGHT);
    ui.row=FILTER;press(SDL_CONTROLLER_BUTTON_A);
    ui.row=FXAA;press(SDL_CONTROLLER_BUTTON_A);
    hakux_menu_video();assert(aspect==1&&filter==1&&fxaa==1);
    uint8_t src[3][256],dst[3][256];
    for(int c=0;c<3;c++)for(int i=0;i<256;i++)src[c][i]=i;
    ui.color=0;hakux_menu_ramp(dst,src);assert(!memcmp(src,dst,sizeof(src)));
    ui.color=1;hakux_menu_ramp(dst,src);assert(dst[0][255]==255&&dst[2][255]<255);
    ui.color=3;hakux_menu_ramp(dst,src);assert(dst[0][255]==255&&dst[0][100]==115);
    struct VolkDeviceTable table={.vkCmdClearAttachments=record};
    bound_w=1280;bound_h=720;hakux_menu_draw((VkCommandBuffer)1,&table,bound_w,bound_h);
    assert(draws==3&&rect_count>500);
    bound_w=640;bound_h=360;hakux_menu_draw((VkCommandBuffer)1,&table,bound_w,bound_h);
    assert(draws==6);
    /* A close action cannot reach the emulated controller until released. */
    buttons[SDL_CONTROLLER_BUTTON_B]=1;assert(hakux_menu_input(pad));assert(!ui.open);
    assert(hakux_menu_input(pad));buttons[SDL_CONTROLLER_BUTTON_B]=0;assert(!hakux_menu_input(pad));
    menu();ui.row=RESTART;press(SDL_CONTROLLER_BUTTON_A);assert(ui.confirm);
    pid_t child=fork();assert(child>=0);
    if(!child) {atexit(teardown_marker);press(SDL_CONTROLLER_BUTTON_A);_exit(99);}
    int status;assert(waitpid(child,&status,0)==child&&WIFEXITED(status)&&WEXITSTATUS(status)==20);
    assert(access("UNSAFE-TEARDOWN",F_OK)!=0);
    f=fopen("render-scale","r");assert(fscanf(f,"%f",&value)==1&&value==.35f);fclose(f);
    char request[80];f=fopen("menu-restart","r");assert(fgets(request,sizeof(request),f)&&!strcmp(request,"restart\n"));fclose(f);
    child=fork();assert(child>=0);
    if(!child) {atexit(teardown_marker);ui.row=QUIT;ui.confirm=false;press(SDL_CONTROLLER_BUTTON_A);press(SDL_CONTROLLER_BUTTON_A);_exit(99);}
    assert(waitpid(child,&status,0)==child&&WIFEXITED(status)&&WEXITSTATUS(status)==0);
    assert(access("UNSAFE-TEARDOWN",F_OK)!=0);
    /* Exercise the physical Menu/Guide evdev path independently of SDL mappings. */
    int pipefd[2];assert(pipe(pipefd)==0);fcntl(pipefd[0],F_SETFL,O_NONBLOCK);
    events[0]=pipefd[0];event_count=1;ui.open=false;ui.guide=false;ui.raw_key=false;
    struct input_event e={.type=EV_KEY,.code=BTN_MODE,.value=1};
    assert(write(pipefd[1],&e,sizeof(e))==sizeof(e));hakux_menu_input(NULL);assert(ui.open);
    close(pipefd[0]);close(pipefd[1]);
    puts("PASS actual menu: navigation, pause/resume, input suppression, live display settings, bounded Vulkan text, confirmed restart, physical Guide events");
}
