#!/usr/bin/env python3
"""Package a supplied ARM64 core; no network, credentials or device access."""
from pathlib import Path
import argparse, hashlib, json, struct, zipfile
root=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser()
p.add_argument('--binary',required=True,type=Path)
p.add_argument('--output',type=Path,default=root/'release/xbox-trimui-smart-pro-2026.10.29.zip')
p.add_argument('--source-root',type=Path,default=root/'port',help='Root containing unpacked source/ and deps/')
a=p.parse_args()
tested='893afce7818b68d294f7ff3258400fd0dc6120c7698d8be0df109d6ef4bdcab2'
sha=lambda b:hashlib.sha256(b).hexdigest()
binary=a.binary.read_bytes()
assert binary[:4]==b'\x7fELF' and binary[4:6]==b'\x02\x01' and struct.unpack_from('<H',binary,18)[0]==183,'Expected 64-bit little-endian AArch64 ELF'
is_tested=sha(binary)==tested
version='2026.10.29' if is_tested else 'local-rebuild'
sources=json.loads((root/'sources/SOURCES.json').read_text())
files={};app='Data/ports/hakux/'
files[app+'hakux.aarch64']=(binary,0o755)
launcher=(root/'port/package/hakux/run.sh').read_text()
needle='mkdir -p cache hdd logs'
assert launcher.count(needle)==1
launcher=launcher.replace(needle,'if [ -z "${HAKUX_RENDER_SCALE:-}" ]; then export HAKUX_RENDER_SCALE=0.5; fi\n'+needle)
needle=': > "$APP/log.txt"';assert launcher.count(needle)==1
launcher=launcher.replace(needle,needle+'\nif [ -r "$APP/runtime-swap.sh" ]; then . "$APP/runtime-swap.sh"; fi')
files[app+'run.sh']=(launcher.encode(),0o755)
files[app+'runtime-swap.sh']=((root/'port/platform/xbox2-swap.sh').read_bytes(),0o755)
files['Data/ports/hakux-disc.sh']=((root/'port/platform/disc-container.sh').read_bytes(),0o755)
config=json.loads((root/'port/package/XBOX/config.json').read_text())
config.update(label='Xbox',iconsmall='iconsmall.png')
assert config['rompath']=='../../Roms/XBOX'
files['Emus/XBOX/config.json']=((json.dumps(config,indent=2)+'\n').encode(),0o644)
files['Emus/XBOX/launch.sh']=(b'#!/bin/sh\nexec /bin/sh /mnt/SDCARD/Data/ports/hakux-disc.sh /mnt/SDCARD/Data/ports/hakux/run.sh "$@"\n',0o755)
icon=(root/'port/package/XBOX/icon.png').read_bytes()
for name in ['icon.png','iconsmall.png']:files['Emus/XBOX/'+name]=(icon,0o644)
for name in ['LICENSE','COPYING']:
    files[app+'licenses/hakuX-'+name]=((a.source_root/'source'/name).read_bytes(),0o644)
for path in sorted((a.source_root/'source/licenses').glob('*.txt')):
    files[app+'licenses/'+path.name]=(path.read_bytes(),0o644)
for component,name in [('SDL2','LICENSE.txt'),('zlib','LICENSE')]:
    files[app+'licenses/'+component+'-LICENSE.txt']=((a.source_root/'deps'/component/name).read_bytes(),0o644)
readme='''Xbox for the original TrimUI Smart Pro TG5040

Install Data/ and Emus/ into the SD card root, merging folders. Games go in
Roms/XBOX. PortMaster is not required. Default scale on a fresh install is 0.5x.
Existing saves, caches, scale, picture and swap settings are not in this payload.
Menu opens settings; hold Start+Select about 1.2 seconds to exit.
Scale changes require Apply scale and restart; save in-game first.

Experimental: missing/black textures, slowdowns, crashes and driver stalls
remain possible. First-run shaders can stutter; persistent black textures
are not fixed by this release. No guaranteed 30 FPS or all-game compatibility.
Swap is automatic for all games: existing configured/system swap is reused;
otherwise 512 MiB is created on writable internal ext4 with at least 1 GiB
free before allocation. First launch may take longer. Existing files/settings
are preserved; setup failures are logged and do not stop the game. Create
disable-swap in the app folder to opt out. Details: docs/INSTALL.md in the
repository. No games, BIOS, saves, swap file or shader cache are bundled.

Based on rfandango/hakuX; matching modified source is in sources/ in the
accompanying repository. License texts are in licenses/. Preserve attribution.
'''
files[app+'README.txt']=(readme.encode(),0o644)
manifest={'name':'hakuX for TrimUI Smart Pro — Xbox','version':version,
 'core_build':'2026-10-29-named-objects-save-1' if is_tested else 'local-rebuild',
 'core_sha256':sha(binary),'hardware':'original TrimUI Smart Pro TG5040 / Cortex-A53 / PowerVR GE8300 / 1 GiB RAM',
 'default_render_scale':0.5,'device_tested_core':is_tested,
 'package_revision':'automatic-swap-1',
 'automatic_swap':{'shared':True,'size_mib':512,'minimum_free_mib':1024,'filesystem':'internal writable ext4','existing_configuration_preserved':True,'creation_device_tested':False},
 'validation': 'Chicago Enforcer gameplay confirmed; other game and stability limits described in docs/COMPATIBILITY.md' if is_tested else 'Local rebuild; device validation required',
 'known_issues':['Halo 2 black/missing textures','game-specific performance and compatibility','possible memory/GPU freezes'],
 'source_archives':{e['file']:e['sha256'] for e in sources['archives']},
 'payload_sha256':{name:sha(value[0]) for name,value in sorted(files.items())}}
files[app+'BUILD.json']=((json.dumps(manifest,indent=2,ensure_ascii=False)+'\n').encode(),0o644)
a.output.parent.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(a.output,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,(data,mode) in sorted(files.items()):
        info=zipfile.ZipInfo(name,date_time=(2026,10,29,0,0,0));info.create_system=3
        info.external_attr=(0o100000|mode)<<16;info.compress_type=zipfile.ZIP_DEFLATED
        z.writestr(info,data)
manifest['install_zip_sha256']=sha(a.output.read_bytes())
manifest['install_zip_bytes']=a.output.stat().st_size
mp=a.output.parent/'BUILD.json';mp.write_text(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n')
(a.output.parent/'SHA256SUMS').write_text(''.join(sha(f.read_bytes())+'  '+f.name+'\n' for f in [a.output,mp]))
print(f'Packaged {a.output.name}: {a.output.stat().st_size/1048576:.2f} MiB; tested core={is_tested}')
