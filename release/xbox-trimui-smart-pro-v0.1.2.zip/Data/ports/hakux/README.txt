hakuX for the original TrimUI Smart Pro (TG5040) - v0.1.2

Copy Data and Emus to the SD card root, merging folders with the game closed.
Put your own Xbox images in Roms/XBOX. Saves, caches and existing choices
are preserved. No game files, BIOS, saves, profiles or cheat/mod packs are
included. This is experimental software; compatibility and speed vary.

Menu opens settings; B returns/resumes. Hold Start + Select about 1.2 seconds
to exit. Controls, picture options, frame skip, scale and LAN save per game
and certificate version under profiles/TITLEID.VERSION. Existing global
files remain the defaults until a game has its own override. Fresh installs
use the original controls, 0.5x scale, frame skip Off and LAN Off.

Scale and LAN changes require Apply settings and restart game; save first.
LAN: Connections on the network exposes the Ethernet-over-UDP tunnel for
local System Link. Matching versions and UDP 3075 are required. Two-console
gameplay is unverified; Xbox Live and direct physical-Xbox bridging are not
provided. See docs/LAN.md in the repository.

Mods and Cheats supports user-supplied, version-matched files. No codes are
bundled or downloaded automatically. Mods require a restart; runtime cheats
apply on resume. toggle8 restores its previous flag value when disabled;
ordinary writes and gameplay/save changes may require a reload to undo.

Take Screenshot saves an opaque PNG to Screenshots/XBOX on the SD card.
The overlay is hidden for capture. The original firmware fbscreencap tool
is required. RGB pixels are preserved and unused alpha/metadata discarded.

MainUI and OSD close during gameplay and return on exit. musicserver pauses
and resumes; its allocated RAM remains. Automatic shared 512 MiB swap uses
eligible internal ext4 storage with at least 1 GiB free before allocation.
Create disable-swap to opt out. Swap does not guarantee higher FPS.

PowerVR eq_depth_step remains enabled. Rendering faults, compilation pauses,
loading blockers, thermal slowdown and crashes remain possible. No universal
30 FPS guarantee. See README and docs for build instructions and limitations.
